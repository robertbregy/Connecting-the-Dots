# Connecting the Dots — data pack

This package supports verification and reuse of the publication’s datasets and methodology. Source provenance remains attached to the project datasets.

Original compilation/schema work is made available under CC BY 4.0 to the extent applicable. Underlying third-party data and source material remain subject to their respective source terms. See `LICENSE-NOTICE.md`.
